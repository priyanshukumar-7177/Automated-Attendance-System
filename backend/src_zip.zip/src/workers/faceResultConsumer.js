/**
 * Face Result Consumer
 * Consumes `attendx.face-results.v1` messages from the Python face worker.
 *
 * Message schema:
 * {
 *   sessionId: string,
 *   courseId:  string,
 *   pictureIndex: number,
 *   totalDetected: number,     // total faces found in photo
 *   matches: [
 *     { studentId: string, confidence: number },  // recognized faces
 *     ...
 *   ],
 *   unidentified: [
 *     { cropCloudinaryId: string, confidence: number },  // unknown faces
 *   ]
 * }
 *
 * Pipeline:
 *  1. For each matched student: push to Redis matched_buffer (bulkWriter drains it)
 *  2. For unidentified faces: insert into unidentified_faces + push crop to Redis
 *  3. Accumulate total_faces counter in Redis
 *  4. When all_images_processed is set: check counter → if 0, auto-finalize
 *  5. Broadcast WS event FACE_RESULT to professor + ATTENDANCE_UPDATED to each matched student
 */

import 'dotenv/config';
import { kafka } from '../kafka/producer.js';
import pool from '../db/pool.js';
import redis from '../redis/client.js';

const TOPIC   = 'attendx.face-results.v1';
const GROUP   = 'attendx-face-result-consumer';

async function handleMessage(payload) {
  const { sessionId, courseId, pictureIndex, totalDetected = 0, matches = [], unidentified = [] } = payload;

  // ── 1. Accumulate total detected faces counter ────────────────────────────
  await redis.incrby(`session:${sessionId}:total_faces`, totalDetected);

  // ── 2. Push matched students into bulk-writer buffer ─────────────────────
  for (const { studentId, confidence } of matches) {
    await redis.rpush(
      `session:${sessionId}:matched_buffer`,
      JSON.stringify({ studentId, confidence, pictureIndex })
    );

    // 🔔 Immediately notify the student their attendance is being recorded
    await redis.publish(
      `attendance:${studentId}:updated`,
      JSON.stringify({
        type: 'ATTENDANCE_UPDATED',
        payload: {
          courseId,
          sessionId,
          date: new Date().toISOString().slice(0, 10),
          status: 'present',
          confidence,
        },
      })
    );
  }

  // ── 3. Insert unidentified face crops ─────────────────────────────────────
  for (const face of unidentified) {
    const { rows: [row] } = await pool.query(
      `INSERT INTO unidentified_faces (session_id, crop_cloudinary_id, confidence)
       VALUES ($1, $2, $3) RETURNING id`,
      [sessionId, face.cropCloudinaryId, face.confidence]
    );
    // Push to Redis for real-time UI
    await redis.rpush(
      `session:${sessionId}:unidentified`,
      JSON.stringify({ faceId: row.id, cropCloudinaryId: face.cropCloudinaryId, confidence: face.confidence })
    );
  }

  // ── 4. Broadcast FACE_RESULT to professor's session room ─────────────────
  await redis.publish(
    `session:${sessionId}:events`,
    JSON.stringify({
      type: 'FACE_RESULT',
      payload: {
        pictureIndex,
        totalDetected,
        matched: matches.map((m) => ({ studentId: m.studentId, confidence: m.confidence })),
        unidentified: unidentified.map((f) => ({
          faceId: null, // DB id not needed here
          cropCloudinaryId: f.cropCloudinaryId,
          confidence: f.confidence,
        })),
      },
    })
  );

  // ── 5. Check if pointer counter hit zero (all photos processed) ───────────
  const meta = await redis.hgetall(`session:${sessionId}:meta`);
  if (meta?.all_images_processed === 'true') {
    const remaining = await redis.get(`session:${sessionId}:total_faces`);
    if (parseInt(remaining, 10) <= 0) {
      // All faces matched — fire PROCESSING_COMPLETE
      const totalMatched = matches.length; // cumulative tracked by bulkWriter
      await redis.publish(
        `session:${sessionId}:events`,
        JSON.stringify({
          type: 'PROCESSING_COMPLETE',
          payload: { sessionId, totalMatched, totalDetected },
        })
      );
    }
  }
}

export function startFaceResultConsumer() {
  const consumer = kafka.consumer({ groupId: GROUP });

  (async () => {
    await consumer.connect();
    await consumer.subscribe({ topic: TOPIC, fromBeginning: false });

    await consumer.run({
      eachMessage: async ({ message }) => {
        try {
          const payload = JSON.parse(message.value.toString());
          await handleMessage(payload);
        } catch (err) {
          console.error('Face result consumer error:', err.message);
        }
      },
    });

    console.log(`Face result consumer running — topic: ${TOPIC}`);
  })().catch((err) => console.error('Failed to start face result consumer:', err.message));
}
