import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { createServer } from 'http';

import authRoutes from './routes/auth.js';
import onboardRoutes from './routes/onboard.js';
import adminRoutes from './routes/admin.js';
import courseRoutes from './routes/courses.js';
import sessionRoutes from './routes/sessions.js';
import superAdminRoutes from './routes/superadmin.js';
import studentRoutes from './routes/students.js';

import { setupWebSocket } from './ws/gateway.js';
import { errorHandler } from './utils/errors.js';
import { runSuperAdminMigration, runV2Migration, runV3Migration, runV4Migration, seedSuperAdmin } from './db/seed.js';

const app = express();
const server = createServer(app);

app.use(cors({ origin: '*' }));
app.use(express.json({ limit: '1mb' }));

app.use('/api/auth', authRoutes);
app.use('/api/onboard', onboardRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/courses', courseRoutes);
app.use('/api/sessions', sessionRoutes);
app.use('/api/superadmin', superAdminRoutes);
app.use('/api/students', studentRoutes);

app.get('/health', (_req, res) => res.json({ status: 'ok' }));

app.use(errorHandler);

setupWebSocket(server);

const PORT = process.env.PORT || 3001;
server.listen(PORT, async () => {
  console.log(`AttendX API Gateway on :${PORT}`);
  // Auto-apply migrations then seed super admin
  await runSuperAdminMigration();
  await runV2Migration();
  await runV3Migration();
  await runV4Migration();
  await seedSuperAdmin();
});
